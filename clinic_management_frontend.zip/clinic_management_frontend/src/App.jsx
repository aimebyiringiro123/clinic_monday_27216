import Offices from './components/Offices.jsx'
import Doctors from './components/Doctors.jsx'
import Patients from './components/Patients.jsx'
import {BrowserRouter,Routes, Route} from 'react-router'

function App() {
  return(
    <>

    <BrowserRouter>
    
    <Routes>
      <Route path="/" element = {<Offices />} />
      <Route path="/doctor" element = {<Doctors />} />
      <Route path="/patient" element = {<Patients />} />
    </Routes>
    
    
    </BrowserRouter>
    


    </>

  ) 
}

export default App
